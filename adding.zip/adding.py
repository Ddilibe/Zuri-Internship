card = 10
box = 20
cardbox = card + box
print(cardbox)